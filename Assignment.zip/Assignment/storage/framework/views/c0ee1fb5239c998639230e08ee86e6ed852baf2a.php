<?php $__env->startSection('sidebar'); ?>
<li class="nav-item active">
    <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
        <i class="material-icons">dashboard</i>
        <p>Dashboard</p>
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('/customers')); ?>">
        <i class="material-icons">people</i>
        <p>Customers</p>
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('/bookings')); ?>">
        <i class="material-icons">local_offer</i>
        <p>Bookings</p>
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('/tours')); ?>">
        <i class="material-icons">directions_bus</i>
        <p>Tours</p>
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('/trips')); ?>">
        <i class="material-icons">calendar_today</i>
        <p>Trips</p>
    </a>
</li>
<?php if(\Illuminate\Support\Facades\Auth::user()->role == 'manager'): ?>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('/staff')); ?>">
        <i class="material-icons">work</i>
        <p>Staff</p>
    </a>
</li>
<?php endif; ?>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('/vehicles')); ?>">
        <i class="material-icons">directions_car</i>
        <p>Vehicles</p>
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(url('/reviews')); ?>">
        <i class="material-icons">rate_review</i>
        <p>Reviews</p>
    </a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<h1 class="navbar-brand">Dashboard</h1>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <img style="display:block;max-width:100%;width:80%;height:18em;margin-left:10%;margin-bottom:2em;" src="<?php echo e(asset('img/PhoenixTravelImg.png')); ?>">
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="card card-chart">
                <div class="card-header card-header-success">
                    <a class="nav-link text-white" href="<?php echo e(url('/customers')); ?>">
                        <h4><i class="material-icons">people</i>
                            Customers</h4>
                    </a>
                </div>
                <div class="card-body">
                    <p class="card-category">
                        <span class="text-success"><?php echo e($count); ?></span> new customers to be approved.</p>
                </div>
                <div class="card-footer">
                    <div class="stats">
                        <i class="material-icons">access_time</i> updated 4 minutes ago
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-chart">
                <div class="card-header card-header-warning">
                    <a class="nav-link text-white" href="<?php echo e(url('/reviews')); ?>">
                        <h4><i class="material-icons">rate_review</i>
                            Reviews</h4>
                    </a>
                </div>
                <div class="card-body">
                    <p class="card-category">
                        <span class="text-success">3</span> new reviews to be approved.
                    </p>
                </div>
                <div class="card-footer">
                    <div class="stats">
                        <i class="material-icons">access_time</i> updated 4 minutes ago
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-chart">
                <div class="card-header card-header-danger">
                    <a class="nav-link text-white" href="<?php echo e(url('/bookings')); ?>">
                        <h4><i class="material-icons">local_offer</i>
                            Bookings</h4>
                    </a>
                </div>
                <div class="card-body">
                    <p class="card-category">
                        <span class="text-success">37</span> new trip bookings.
                    </p>
                </div>
                <div class="card-footer">
                    <div class="stats">
                        <i class="material-icons">access_time</i> updated 4 minutes ago
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>