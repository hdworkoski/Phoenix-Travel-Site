<?php $__env->startSection('sidebar'); ?>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/login')); ?>">
            <i class="material-icons">person</i>
            <p>Staff Log In</p>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <h1 class="navbar-brand">Log In</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div style="margin-left:20%;margin-right:20%;margin-top:10%;">
        <div class="card text-center">
            <div class="card-header card-header-info">
                Staff Log In
            </div>
            <div class="card-body text-center">
                <form class="form" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <div class="row">
                            <div class="input-group-prepend col col-sm-1">
                                <span class="input-group-text">
                                    <i class="material-icons">person</i>
                                </span>
                            </div>
                            <div class="col col-md-10">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" required autofocus>
                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <div class="row">
                            <div class="input-group-prepend col col-sm-1">
                                <span class="input-group-text">
                                    <i class="material-icons">lock</i>
                                </span>
                            </div>
                            <div class="col col-md-10">
                                <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <div class="col-md-12">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-default">
                                Login
                            </button>
                            <br/>
                            <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                Forgot Your Password?
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>