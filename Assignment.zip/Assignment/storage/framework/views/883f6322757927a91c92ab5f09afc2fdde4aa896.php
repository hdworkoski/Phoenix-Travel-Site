<?php $__env->startSection('sidebar'); ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/customers')); ?>">
            <i class="material-icons">people</i>
            <p>Customers</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/bookings')); ?>">
            <i class="material-icons">local_offer</i>
            <p>Bookings</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/tours')); ?>">
            <i class="material-icons">directions_bus</i>
            <p>Tours</p>
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/trips')); ?>">
            <i class="material-icons">calendar_today</i>
            <p>Trips</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/staff')); ?>">
            <i class="material-icons">work</i>
            <p>Staff</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/vehicles')); ?>">
            <i class="material-icons">directions_car</i>
            <p>Vehicles</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/reviews')); ?>">
            <i class="material-icons">rate_review</i>
            <p>Reviews</p>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <h1 class="navbar-brand">Trips</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if($error == 1): ?>
            <div class="badge-danger">
                You cannot delete a trip that has associated bookings.
            </div>
        <?php endif; ?>
            <div class="row">
                <a class="text-white" href="<?php echo e(url('/trip')); ?>"><button class="btn btn-default pull-left">Add New Trip</button></a>
            </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-info">
                        <h4 class="card-title">Trips</h4>
                        <p class="card-category">All Trip Details</p>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="text-info">
                                <th class="text-center">
                                    Trip ID
                                </th>
                                <th class="text-center">
                                    Tour Number
                                </th>
                                <th class="text-center">
                                    Vehicle Rego Number
                                </th>
                                <th class="text-center">
                                    Departure Date
                                </th>
                                <th class="text-center">
                                    Max Passengers
                                </th>
                                <th class="text-center">
                                    Standard Amount
                                </th>
                                <th class="text-center">
                                    &nbsp;
                                </th>
                                <th class="text-center">
                                    &nbsp;
                                </th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center">
                                        <form action="/trip/view/<?php echo e($t->Trip_Id); ?>" method="GET">
                                            <?php echo e(csrf_field()); ?>

                                            <button type="submit" class="btn btn-white text-info">
                                                <?php echo e($t->Trip_Id); ?>

                                            </button>
                                        </form>
                                    </td>
                                    <td class="text-center">
                                        <?php echo e($t->Tour_No); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($t->Rego_No); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($t->Departure_Date); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($t->Max_Passengers); ?>

                                    </td>
                                    <td class="text-center">
                                        $<?php echo e($t->Standard_Amount); ?>

                                    </td>
                                    <td class="text-center">
                                        <form action="/trip/<?php echo e($t->Trip_Id); ?>" method="GET">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('UPDATE')); ?>


                                            <button type="submit" class="btn bg-white">
                                                <i class="material-icons text-success">edit</i>
                                            </button>
                                        </form>
                                    </td>
                                    <form action="/trip/<?php echo e($t->Trip_Id); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <td class="text-center">
                                            <button type="submit" class="btn btn-white btnDeleteTrip">
                                                <i class="material-icons text-danger">delete</i>
                                            </button>
                                        </td>
                                    </form>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>