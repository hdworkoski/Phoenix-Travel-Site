<?php $__env->startSection('sidebar'); ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/customers')); ?>">
            <i class="material-icons">people</i>
            <p>Customers</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/bookings')); ?>">
            <i class="material-icons">local_offer</i>
            <p>Bookings</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/tours')); ?>">
            <i class="material-icons">directions_bus</i>
            <p>Tours</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/trips')); ?>">
            <i class="material-icons">calendar_today</i>
            <p>Trips</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/staff')); ?>">
            <i class="material-icons">work</i>
            <p>Staff</p>
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/vehicles')); ?>">
            <i class="material-icons">directions_car</i>
            <p>Vehicles</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/reviews')); ?>">
            <i class="material-icons">rate_review</i>
            <p>Reviews</p>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <h1 class="navbar-brand">Vehicles</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-info">
                        <h4 class="card-title">Vehicles</h4>
                        <p class="card-category">All Vehicle Details</p>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="text-info">
                                <th class="text-center">
                                    Rego Number
                                </th>
                                <th class="text-center">
                                    VIN
                                </th>
                                <th class="text-center">
                                    Make
                                </th>
                                <th class="text-center">
                                    Model
                                </th>
                                <th class="text-center">
                                    Year
                                </th>
                                <th class="text-center">
                                    Capacity
                                </th>
                                <th class="text-center">
                                    Fuel Type
                                </th>
                                <th class="text-center">
                                    Equipment
                                </th>
                                <th class="text-center">
                                    License Required
                                </th>
                                <th class="text-center">
                                    &nbsp;
                                </th>
                                <th class="text-center">
                                    &nbsp;
                                </th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-info text-center">
                                        <?php echo e($v->Rego_No); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($v->VIN); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($v->Make); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($v->Model); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($v->Year); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($v->Capacity); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($v->Fuel_Type); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($v->Equipment); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($v->Licence_Required); ?>

                                    </td>
                                    <td class="text-center">
                                        <i class="material-icons text-gray">edit</i>
                                    </td>
                                    <td class="text-center">
                                        <i class="material-icons text-danger">delete</i>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>