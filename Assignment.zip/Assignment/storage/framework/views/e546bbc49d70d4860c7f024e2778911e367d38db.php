<?php $__env->startSection('sidebar'); ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/customers')); ?>">
            <i class="material-icons">people</i>
            <p>Customers</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/bookings')); ?>">
            <i class="material-icons">local_offer</i>
            <p>Bookings</p>
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/tours')); ?>">
            <i class="material-icons">directions_bus</i>
            <p>Tours</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/trips')); ?>">
            <i class="material-icons">calendar_today</i>
            <p>Trips</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/staff')); ?>">
            <i class="material-icons">work</i>
            <p>Staff</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/vehicles')); ?>">
            <i class="material-icons">directions_car</i>
            <p>Vehicles</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/reviews')); ?>">
            <i class="material-icons">rate_review</i>
            <p>Reviews</p>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <h1 class="navbar-brand">Tours</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(count($tour) > 0): ?>
    <div class="container-fluid">
        <?php if($error == 1): ?>
            <div class="badge-danger">
                You cannot delete a tour that has associated trips or itineraries.
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-info">
                        <h4 class="card-title">Tours</h4>
                        <p class="card-category">All Tour Details</p>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="text-info">
                                <th class="text-center">
                                    Tour Number
                                </th>
                                <th class="text-center">
                                    Name
                                </th>
                                <th class="text-center">
                                    Description
                                </th>
                                <th class="text-center">
                                    Duration
                                </th>
                                <th class="text-center">
                                    Route Map
                                </th>
                                <th class="text-center">
                                    Itinerary
                                </th>
                                <th class="text-center">
                                    &nbsp;
                                </th>
                                <th class="text-center">
                                    &nbsp;
                                </th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-info text-center">
                                            <div><?php echo e($t->Tour_No); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($t->Tour_Name); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($t->Description); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($t->Duration); ?></div> Days
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e(str_limit($t->Route_Map, $limit = 20, $end = '...')); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <form action="/itineraries/<?php echo e($t->Tour_No); ?>" method="GET">
                                                <?php echo e(csrf_field()); ?>


                                                <button type="submit" class="btn bg-white">
                                                    <i class="material-icons text-warning">schedule</i>
                                                </button>
                                            </form>
                                        </td>
                                        <td class="text-center">
                                            <form action="/tour/<?php echo e($t->Tour_No); ?>" method="GET">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('UPDATE')); ?>


                                                <button type="submit" class="btn bg-white">
                                                    <i class="material-icons text-success">edit</i>
                                                </button>
                                            </form>
                                        </td>
                                        <td class="text-center">
                                            <form action="/tour/<?php echo e($t->Tour_No); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>


                                                <button type="submit" class="btn bg-white btnDeleteTour">
                                                    <i class="material-icons text-danger">delete</i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <a class="text-white" href="<?php echo e(url('/tour')); ?>"><button class="btn btn-default pull-left">Add New Tour</button></a>
            &nbsp;
            <a class="text-white" href="<?php echo e(url('/tours/departures')); ?>"><button class="btn btn-default">View Tour Departures</button></a>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>