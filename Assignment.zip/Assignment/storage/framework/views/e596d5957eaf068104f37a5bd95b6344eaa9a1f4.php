<?php $__env->startSection('sidebar'); ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/customers')); ?>">
            <i class="material-icons">people</i>
            <p>Customers</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/bookings')); ?>">
            <i class="material-icons">local_offer</i>
            <p>Bookings</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/tours')); ?>">
            <i class="material-icons">directions_bus</i>
            <p>Tours</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/trips')); ?>">
            <i class="material-icons">calendar_today</i>
            <p>Trips</p>
        </a>
    </li>
    <?php if(\Illuminate\Support\Facades\Auth::user()->role == 'manager'): ?>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/staff')); ?>">
            <i class="material-icons">work</i>
            <p>Staff</p>
        </a>
    </li>
    <?php endif; ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/vehicles')); ?>">
            <i class="material-icons">directions_car</i>
            <p>Vehicles</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/reviews')); ?>">
            <i class="material-icons">rate_review</i>
            <p>Reviews</p>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <h1 class="navbar-brand">Staff</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <a class="text-white" href="<?php echo e(url('/staff/add/new')); ?>"><button class="btn btn-default pull-left">Add New Staff Member</button></a>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-info">
                        <h4 class="card-title">Staff</h4>
                        <p class="card-category">All Staff Details</p>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="text-info">
                                <th class="text-center">
                                    Staff ID
                                </th>
                                <th class="text-center">
                                    Position
                                </th>
                                <th class="text-center">
                                    First Name
                                </th>
                                <th class="text-center">
                                    Middle Initial
                                </th>
                                <th class="text-center">
                                    Last Name
                                </th>
                                <th class="text-center">
                                    Street Number
                                </th>
                                <th class="text-center">
                                    Street Name
                                </th>
                                <th class="text-center">
                                    Suburb
                                </th>
                                <th class="text-center">
                                    Postcode
                                </th>
                                <th class="text-center">
                                    Email
                                </th>
                                <th class="text-center">
                                    Phone
                                </th>
                                <th class="text-center">
                                    &nbsp;
                                </th>
                                <th class="text-center">
                                    &nbsp;
                                </th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-info text-center">
                                            <div><?php echo e($s->Staff_id); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($s->Position); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($s->First_Name); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($s->Middle_Initial); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($s->Last_Name); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($s->Street_No); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($s->Street_Name); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($s->Suburb); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($s->Postcode); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($s->Email); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <div><?php echo e($s->Phone); ?></div>
                                        </td>
                                        <td class="text-center">
                                            <form action="/staff/<?php echo e($s->Staff_id); ?>/<?php echo e($s->Email); ?>" method="GET">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('UPDATE')); ?>


                                                <button type="submit" class="btn bg-white">
                                                    <i class="material-icons text-success">edit</i>
                                                </button>
                                            </form>
                                        </td>
                                        <td class="text-center">
                                            <form action="/staff/<?php echo e($s->Staff_id); ?>/<?php echo e($s->Email); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>


                                                <button type="submit" class="btn bg-white btnDeleteStaff">
                                                    <i class="material-icons text-danger">delete</i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>