<?php $__env->startSection('sidebar'); ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/customers')); ?>">
            <i class="material-icons">people</i>
            <p>Customers</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/bookings')); ?>">
            <i class="material-icons">local_offer</i>
            <p>Bookings</p>
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/tours')); ?>">
            <i class="material-icons">directions_bus</i>
            <p>Tours</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/trips')); ?>">
            <i class="material-icons">calendar_today</i>
            <p>Trips</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/staff')); ?>">
            <i class="material-icons">work</i>
            <p>Staff</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/vehicles')); ?>">
            <i class="material-icons">directions_car</i>
            <p>Vehicles</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/reviews')); ?>">
            <i class="material-icons">rate_review</i>
            <p>Reviews</p>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <h1 class="navbar-brand">Tour Itinerary</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
        <?php if($tour): ?>
            <?php if($add == 0): ?>
        <form action="/itineraries/<?php echo e($tour); ?>/add" method="GET">
            <?php echo e(csrf_field()); ?>

            <button type="submit" class="btn btn-default">Add Itinerary For Tour #<?php echo e($tour); ?></button>
        </form>
            <?php endif; ?>
        <?php endif; ?>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header card-header-info">
                        <h4 class="card-title">Tour #<?php echo e($tour); ?></h4>
                    </div>
                    <div class="card-body">
                        <h4>Name:</h4><p><?php echo e($t[0]->Tour_Name); ?></p>
                        <h4>Description:</h4><p><?php echo e($t[0]->Description); ?></p>
                        <h4>Duration:</h4><p><?php echo e($t[0]->Duration); ?></p>
                        <h4>Route Map:</h4><p><?php echo e($t[0]->Route_Map); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-info">
                        <h4 class="card-title">Tour Itinerary</h4>
                        <p class="card-category">Itinerary Details</p>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="text-info">
                                <th class="text-center">
                                    Itinerary ID
                                </th>
                                <th class="text-center">
                                    Tour Number
                                </th>
                                <th class="text-center">
                                    Day Number
                                </th>
                                <th class="text-center">
                                    Hotel Booking Number
                                </th>
                                <th class="text-center">
                                    Activities
                                </th>
                                <th class="text-center">
                                    Meals
                                </th>
                                <th>
                                    &nbsp;
                                </th>
                                <th>
                                    &nbsp;
                                </th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $itineraries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-info text-center">
                                        <?php echo e($i->id); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($i->Tour_No); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($i->Day_No); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($i->Hotel_Booking_No); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($i->Activities); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($i->Meals); ?>

                                    </td>
                                    <td class="text-center">
                                        <form action="/itinerary/edit/<?php echo e($i->id); ?>" method="GET">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('UPDATE')); ?>


                                            <button type="submit" class="btn bg-white">
                                                <i class="material-icons text-success">edit</i>
                                            </button>
                                        </form>
                                    </td>
                                    <td class="text-center">
                                        <form action="/itineraries/<?php echo e($i->id); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>


                                            <button type="submit" class="btn bg-white btnDeleteItinerary">
                                                <i class="material-icons text-danger">delete</i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($add > 0): ?>
                                    <tr>
                                        <form action="<?php echo e(action('ItineraryController@commit')); ?>" method="POST" class="form-horizontal">
                                        <?php echo csrf_field(); ?>

                                        <td class="text-info text-center">
                                            &nbsp;
                                        </td>
                                        <td class="text-center">
                                            <div class="form-group">
                                            <input type="number" name="Tour_No" id="Tour_No" class="form-control" value="<?php echo e($tour); ?>" hidden>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-group">
                                            <input type="number" name="Day_No" id="Day_No" class="form-control" placeholder="Day Number">
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-group">
                                            <input type="text" name="Hotel_Booking_No" id="Hotel_Booking_No" class="form-control" placeholder="Hotel Booking Number">
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-group">
                                            <input type="text" name="Activities" id="Activities" class="form-control" placeholder="Activities">
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-group">
                                            <input type="text" name="Meals" id="Meals" class="form-control" placeholder="Meals">
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="form-group">
                                                <button type="submit" class="btn bg-white">
                                                <i class="material-icons text-success">check</i>
                                            </button>
                                            </div>
                                        </td></form>
                                        <form action="/itineraries/<?php echo e($tour); ?>" method="GET">
                                        <td class="text-center">
                                            <button type="submit" class="btn bg-white">
                                                <i class="material-icons text-danger">cancel</i>
                                            </button>
                                        </td>
                                        </form>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <a class="text-white" href="<?php echo e(url('/tours')); ?>"><button class="btn btn-info pull-left btn-default">Back to Tours</button></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>