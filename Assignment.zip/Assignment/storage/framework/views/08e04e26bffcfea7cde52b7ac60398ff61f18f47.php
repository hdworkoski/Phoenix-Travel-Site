<?php $__env->startSection('sidebar'); ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/customers')); ?>">
            <i class="material-icons">people</i>
            <p>Customers</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/bookings')); ?>">
            <i class="material-icons">local_offer</i>
            <p>Bookings</p>
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/tours')); ?>">
            <i class="material-icons">directions_bus</i>
            <p>Tours</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/trips')); ?>">
            <i class="material-icons">calendar_today</i>
            <p>Trips</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/staff')); ?>">
            <i class="material-icons">work</i>
            <p>Staff</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/vehicles')); ?>">
            <i class="material-icons">directions_car</i>
            <p>Vehicles</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/reviews')); ?>">
            <i class="material-icons">rate_review</i>
            <p>Reviews</p>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <h1 class="navbar-brand">Edit Itinerary</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header card-header-info">
                        <h4 class="card-title">Edit Itinerary</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('/itineraries/update')); ?>" method="POST" class="form-horizontal">
                            <?php echo csrf_field(); ?>


                            <div class="text-center">
                                <input type="number" name="id" id="id" class="form-control" value="<?php echo e($i->id); ?>" hidden>
                            </div>
                            <div class="text-center">
                                <input type="number" name="Tour_No" id="Tour_No" class="form-control" value="<?php echo e($i->Tour_No); ?>" hidden>
                            </div>
                            <div class="text-center">
                                <input type="number" name="Day_No" id="Day_No" class="form-control" value="<?php echo e($i->Day_No); ?>" placeholder="Day Number">
                            </div>
                            <div class="text-center">
                                <input type="text" name="Hotel_Booking_No" id="Hotel_Booking_No" class="form-control"value="<?php echo e($i->Hotel_Booking_No); ?>"  placeholder="Hotel Booking Number">
                            </div>
                            <div class="text-center">
                                <input type="text" name="Activities" id="Activities" class="form-control" value="<?php echo e($i->Activities); ?>" placeholder="Activities">
                            </div>
                            <div class="text-center">
                                <input type="text" name="Meals" id="Meals" class="form-control" value="<?php echo e($i->Meals); ?>" placeholder="Meals">
                            </div>
                            <div>
                                <button type="submit" class="btn btn-default">
                                    Save Itinerary
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <form action="/itineraries/<?php echo e($i->Tour_No); ?>" method="GET">
                <?php echo e(csrf_field()); ?>


                <button type="submit" class="btn btn-default">
                    Back to Itineraries
                </button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>