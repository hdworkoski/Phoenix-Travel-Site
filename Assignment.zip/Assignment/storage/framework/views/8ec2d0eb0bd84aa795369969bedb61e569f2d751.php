<?php $__env->startSection('sidebar'); ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/customers')); ?>">
            <i class="material-icons">people</i>
            <p>Customers</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/bookings')); ?>">
            <i class="material-icons">local_offer</i>
            <p>Bookings</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/tours')); ?>">
            <i class="material-icons">directions_bus</i>
            <p>Tours</p>
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/trips')); ?>">
            <i class="material-icons">calendar_today</i>
            <p>Trips</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/staff')); ?>">
            <i class="material-icons">work</i>
            <p>Staff</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/vehicles')); ?>">
            <i class="material-icons">directions_car</i>
            <p>Vehicles</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/reviews')); ?>">
            <i class="material-icons">rate_review</i>
            <p>Reviews</p>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <h1 class="navbar-brand">Trip Details</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <a class="text-white" href="<?php echo e(url('/trips')); ?>"><button class="btn btn-default pull-left">Back to Trips</button></a>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header card-header-info">
                        <h4 class="card-title">Trip #<?php echo e($t->Trip_Id); ?></h4>
                    </div>
                    <div class="card-body">
                        <h4>Vehicle:</h4><p><?php echo e($t->Rego_No); ?></p>
                        <h4>Departure Date:</h4><p><?php echo e($t->Departure_Date); ?></p>
                        <h4>Max Passengers:</h4><p><?php echo e($t->Max_Passengers); ?></p>
                        <h4>Standard Amount:</h4><p><?php echo e($t->Standard_Amount); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header card-header-info">
                        <h4 class="card-title">Tour #<?php echo e($tour->Tour_No); ?></h4>
                    </div>
                    <div class="card-body">
                        <h4>Name:</h4><p><?php echo e($tour->Tour_Name); ?></p>
                        <h4>Description:</h4><p><?php echo e($tour->Description); ?></p>
                        <h4>Duration:</h4><p><?php echo e($tour->Duration); ?></p>
                        <h4>Route Map:</h4><p><?php echo e($tour->Route_Map); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header card-header-info">
                        <h4 class="card-title">Customer List</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead class="text-info">
                                <th class="text-center">
                                    Customer ID
                                </th>
                                <th class="text-center">
                                    Name
                                </th>
                                <th class="text-center">
                                    Number on Booking
                                </th>
                                <th class="text-center">
                                    Deposit Amount
                                </th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-info text-center"><?php echo e($c->Customer_id); ?></td>
                                    <td class="text-center"><?php echo e($c->First_Name); ?> <?php echo e($c->Middle_Initial); ?> <?php echo e($c->Last_Name); ?></td>
                                    <td class="text-center"><?php echo e($c->Number_Of_Bookings); ?></td>
                                    <td class="text-center"><?php echo e($c->Deposit_Amount); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>