<?php $__env->startSection('sidebar'); ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
            <i class="material-icons">dashboard</i>
            <p>Dashboard</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/customers')); ?>">
            <i class="material-icons">people</i>
            <p>Customers</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/bookings')); ?>">
            <i class="material-icons">local_offer</i>
            <p>Bookings</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/tours')); ?>">
            <i class="material-icons">directions_bus</i>
            <p>Tours</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/trips')); ?>">
            <i class="material-icons">calendar_today</i>
            <p>Trips</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/staff')); ?>">
            <i class="material-icons">work</i>
            <p>Staff</p>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/vehicles')); ?>">
            <i class="material-icons">directions_car</i>
            <p>Vehicles</p>
        </a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(url('/reviews')); ?>">
            <i class="material-icons">rate_review</i>
            <p>Reviews</p>
        </a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <h1 class="navbar-brand">Reviews</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        &nbsp;
        <a href="/reviews/trips" class="btn btn-default">Review Statistics - Trips</a>&nbsp;&nbsp;
        <a href="/reviews/tours" class="btn btn-default">Review Statistics - Tours</a>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header card-header-info">
                    <h4 class="card-title">Customer Reviews</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="text-info">
                                <th class="text-center">
                                    Review ID
                                </th>
                                <th class="text-center">
                                    Trip Booking Number
                                </th>
                                <th class="text-center">
                                    Rating
                                </th>
                                <th class="text-center">
                                    General Feedback
                                </th>
                                <th class="text-center">
                                    Likes
                                </th>
                                <th class="text-center">
                                    Dislikes
                                </th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-info text-center">
                                        <?php echo e($r->Review_id); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($r->Trip_Booking_No); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($r->Rating); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($r->General_Feedback); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($r->Likes); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php echo e($r->Dislikes); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>